import arg from 'arg';
const fs = require('fs');
require('colors');
const Diff = require('diff');

function parseArgumentsIntoOptions(rawArgs) {

  //slicing the arguments and taking the filepaths
  var args = arg({}, { argv: rawArgs.slice(2) });
  //console.log(args);
  return args;
}

//main function called from diff-project file
export async function cli(args) {

  //getting the raw arguments parsed
  let options = parseArgumentsIntoOptions(args);
  var file1path = options._[0];
  var file2path = options._[1];

  //reading from files
  var file1content = await readfromfile(file1path);
  var file2content = await readfromfile(file2path);
 
  console.log("\nRed Character-Present in file1 only\nGreen Character-Present in file2 only\nGrey Character-Same content\n");
  //calling diffChars method from Diff package with file contents
  const diff = Diff.diffChars(file1content, file2content);

  var red = 0;
  var green = 0;

  //iterating through the differences
  diff.forEach((part) => {
    // green for additions, red for deletions
    // grey for common parts
    const color = part.added ? 'green' :
      part.removed ? 'red' : 'grey';
    if (color == 'green') ++green;
    if (color == 'red') ++red;
    process.stderr.write(part.value[color]);
  });

  console.log("\nThere are ", red, " changes to be removed from file1 and\n", green, " changes to be added to file1");

  //for error handling
  process.on('uncaughtException', function (err) {
  });
}
async function readfromfile(path) {
  //reading from file using await keyword which helps in synchronization
  const data = await fs.promises.readFile(path, "UTF-8");
  // console.log(data);
  return data;
}
